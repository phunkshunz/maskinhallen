@echo off
rem Installs FUKT Lite on Windows. Double-click this file.
rem The VST3 folder needs administrator rights, so the file asks for them itself.

net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0'"
  exit /b
)

cd /d "%~dp0"
set "DEST=%CommonProgramFiles%\VST3"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\FUKT Lite.vst3" rmdir /s /q "%DEST%\FUKT Lite.vst3"
xcopy "FUKT Lite.vst3" "%DEST%\FUKT Lite.vst3\" /e /i /y /q >nul

if errorlevel 1 (
  echo.
  echo Something went wrong. Did you unzip first? Right-click the zip file and choose "Extract All".
  pause
  exit /b 1
)

echo.
echo Done! FUKT Lite is now in:
echo   %DEST%
echo Restart your DAW or rescan plugins. Full version: https://payhip.com/MASKINHALLEN
echo.
pause
