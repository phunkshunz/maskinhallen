#!/bin/bash
# Installerar TURBIN-DEMO-DEMO. Kör från Terminal:  bash installera.command
set -e
cd "$(dirname "$0")"

VST3="$HOME/Library/Audio/Plug-Ins/VST3"
AU="$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$VST3" "$AU"

rm -rf "$VST3/TURBIN-DEMO.vst3" "$AU/TURBIN-DEMO.component"
cp -R TURBIN-DEMO.vst3 "$VST3/"
cp -R TURBIN-DEMO.component "$AU/"

# Pluginet är osignerat, så macOS spärrar det. Detta tar bort spärren.
xattr -dr com.apple.quarantine "$VST3/TURBIN-DEMO.vst3" "$AU/TURBIN-DEMO.component" TURBIN-DEMO.app 2>/dev/null || true

echo ""
echo "Klart! TURBIN-DEMO ligger nu i:"
echo "  $VST3"
if [ -e "$VST3/VALV.vst3" ] || [ -e "$AU/VALV.component" ]; then
  echo ""
  echo "Obs: gamla VALV ligger kvar. TURBIN ersätter den i samma repo."
  echo "Vill du ta bort den: radera VALV.vst3 och VALV.component i mapparna ovan."
fi
echo "Stäng Bitwig helt och starta igen. TURBIN ligger bland instrumenten."
