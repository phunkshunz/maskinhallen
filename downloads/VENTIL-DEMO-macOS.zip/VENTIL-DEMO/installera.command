#!/bin/bash
# Installerar VENTIL-DEMO-DEMO. Kör från Terminal:  bash installera.command
set -e
cd "$(dirname "$0")"

VST3="$HOME/Library/Audio/Plug-Ins/VST3"
AU="$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$VST3" "$AU"

rm -rf "$VST3/VENTIL-DEMO.vst3" "$AU/VENTIL-DEMO.component"
cp -R VENTIL-DEMO.vst3 "$VST3/"
cp -R VENTIL-DEMO.component "$AU/"

# Pluginet är osignerat, så macOS spärrar det. Detta tar bort spärren.
xattr -dr com.apple.quarantine "$VST3/VENTIL-DEMO.vst3" "$AU/VENTIL-DEMO.component" VENTIL-DEMO.app 2>/dev/null || true

echo ""
echo "Klart! VENTIL-DEMO ligger nu i:"
echo "  $VST3"
if [ -e "$VST3/R-744.vst3" ] || [ -e "$AU/R-744.component" ]; then
  echo ""
  echo "Obs: gamla R-744 ligger kvar. VENTIL ersätter den i samma repo."
  echo "Vill du ta bort den: radera R-744.vst3 och R-744.component i mapparna ovan."
fi
echo "Stäng Bitwig helt och starta igen. VENTIL ligger bland effekterna."
