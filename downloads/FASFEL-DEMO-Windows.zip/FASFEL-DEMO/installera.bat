@echo off
REM FASFEL - MASKINHALLEN / Phunkshunz AUDIO
REM Hogerklicka och valj "Kor som administrator".

set "DEST=%CommonProgramFiles%\VST3"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\FASFEL-DEMO.vst3" rmdir /s /q "%DEST%\FASFEL-DEMO.vst3"
xcopy /e /i /y "%~dp0FASFEL-DEMO.vst3" "%DEST%\FASFEL-DEMO.vst3" >nul
if errorlevel 1 (
  echo.
  echo   Misslyckades. Hogerklicka pa installera.bat och valj "Kor som administrator".
) else (
  echo.
  echo   Klart! FASFEL-DEMO finns nu i %DEST%
  echo   Starta om din DAW och skanna plugins.
)
echo.
pause
