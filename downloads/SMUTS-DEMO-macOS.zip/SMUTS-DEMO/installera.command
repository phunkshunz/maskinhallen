#!/bin/bash
# Installerar SMUTS-DEMO-DEMO. Kör från Terminal:  bash installera.command
set -e
cd "$(dirname "$0")"

VST3="$HOME/Library/Audio/Plug-Ins/VST3"
AU="$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$VST3" "$AU"

rm -rf "$VST3/SMUTS-DEMO.vst3" "$AU/SMUTS-DEMO.component"
cp -R SMUTS-DEMO.vst3 "$VST3/"
cp -R SMUTS-DEMO.component "$AU/"

# Pluginet är osignerat, så macOS spärrar det. Detta tar bort spärren.
xattr -cr "$VST3/SMUTS-DEMO.vst3" "$AU/SMUTS-DEMO.component" SMUTS-DEMO.app 2>/dev/null || true

echo ""
echo "Klart! SMUTS-DEMO ligger nu i:"
echo "  $VST3"
echo "VIKTIGT: stäng Bitwig helt (Cmd+Q) och starta igen. Rescan räcker inte,"
echo "Bitwig håller kvar den gamla versionen i minnet tills programmet startas om."
echo "Kolla sedan att statusraden i SMUTS visar rätt BYGGE-nummer."
