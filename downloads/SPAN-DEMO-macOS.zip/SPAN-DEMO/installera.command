#!/bin/bash
# Installerar SPÅN. Kör från Terminal:  bash installera.command
set -e
cd "$(dirname "$0")"

VST3="$HOME/Library/Audio/Plug-Ins/VST3"
AU="$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$VST3" "$AU"

rm -rf "$VST3/SPAN-DEMO.vst3" "$AU/SPAN-DEMO.component"
cp -R SPAN-DEMO.vst3 "$VST3/"
cp -R SPAN-DEMO.component "$AU/"

# Pluginet är osignerat, så macOS spärrar det. Detta tar bort spärren.
xattr -dr com.apple.quarantine "$VST3/SPAN-DEMO.vst3" "$AU/SPAN-DEMO.component" SPAN-DEMO.app 2>/dev/null || true

echo ""
echo "Klart! SPÅN ligger nu i:"
echo "  $VST3"
if [ -e "$VST3/MASUGN.vst3" ] || [ -e "$AU/MASUGN.component" ]; then
  echo ""
  echo "Obs: gamla MASUGN ligger kvar. SPÅN ersätter den i samma repo."
  echo "Vill du ta bort den: radera MASUGN.vst3 och MASUGN.component i mapparna ovan."
fi
echo "Stäng Bitwig helt och starta igen. SPÅN heter SPAN bland instrumenten."
