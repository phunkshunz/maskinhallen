#!/bin/bash
# Installs FUKT Lite. Run from Terminal:  bash ~/Downloads/FUKT-Lite/install-lite.command
set -e
cd "$(dirname "$0")"

VST3="$HOME/Library/Audio/Plug-Ins/VST3"
AU="$HOME/Library/Audio/Plug-Ins/Components"
mkdir -p "$VST3" "$AU"

rm -rf "$VST3/FUKT Lite.vst3" "$AU/FUKT Lite.component"
cp -R "FUKT Lite.vst3" "$VST3/"
cp -R "FUKT Lite.component" "$AU/"

# The plugin is not signed by Apple yet, so macOS blocks it. This removes the block.
xattr -dr com.apple.quarantine "$VST3/FUKT Lite.vst3" "$AU/FUKT Lite.component" "FUKT Lite.app" 2>/dev/null || true

echo ""
echo "Done! FUKT Lite is now in:"
echo "  $VST3"
echo "Restart your DAW or rescan plugins. Full version: https://payhip.com/MASKINHALLEN"
