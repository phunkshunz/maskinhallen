@echo off
REM KULVERT - MASKINHALLEN / Phunkshunz AUDIO
REM Hogerklicka och valj "Kor som administrator".

set "DEST=%CommonProgramFiles%\VST3"
if not exist "%DEST%" mkdir "%DEST%"
if exist "%DEST%\KULVERT-DEMO.vst3" rmdir /s /q "%DEST%\KULVERT-DEMO.vst3"
xcopy /e /i /y "%~dp0KULVERT-DEMO.vst3" "%DEST%\KULVERT-DEMO.vst3" >nul
if errorlevel 1 (
  echo.
  echo   Misslyckades. Hogerklicka pa installera.bat och valj "Kor som administrator".
) else (
  echo.
  echo   Klart! KULVERT-DEMO finns nu i %DEST%
  echo   Starta om din DAW och skanna plugins.
)
echo.
pause
